package br.javaweb.ecommerce;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CatalogoProdutosView extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        // Obtencao do canal de envio de dados para o cliente
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Catalogo Produtos - Academia do Java</title>");
        out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
        out.println("<link href= 'aj.css' rel='stylesheet' type='text/css'>");
        out.println("<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\" media=\"screen\" />");
        out.println("</head>");
        out.println("<body>");
        out.println("<H3>Confira abaixo nossos jogos:</H3><br/>");
        // Inicio da tabela de produtos
        out.println("<TABLE width = '700' border='1' align=center>");

        //Linha de titulo
        out.println("<TR width = '%100' class='tituloCampo'>");
        out.println("<TD width = '%20'>Imagem</TD>");
        out.println("<TD width = '%10' >Nome</TD>");
        out.println("<TD width = '%10' >Codigo</TD>");
        out.println("<TD width = '%10'  >Descri&ccedil;&atilde;o</TD>");
        out.println("<TD width = '%10' >Pre&ccedil;o</TD>");
        out.println("<TD width = '%20' colspan = '2'>Comprar</TD>");
        out.println("</TR>");

        // -------------------------------------------------------------------
        // Insira a partir daqui o codigo pedido no laboratorio:
        // -------------------------------------------------------------------


        
        
        // Primeiro produto
        out.println("<TR width = '%100'>");
        out.println("<TD width = '%20'> <IMG SRC = 'imagem/game1.jpg'/></TD>");
        out.println("<TD width = '%10'  class='gridCampo'>PES 2013</TD>");
        out.println("<TD width = '%10' class='gridCampo'>PS3</TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Jogo de Futebol</TD>");
        out.println("<TD width = '%10' class='gridCampo'>R$ 100,00</TD>");
        out.println("<TD width = '%20' colspan = '2'><A HREF= 'adicionarProdutoCarrinho?idProduto=82' ><IMG SRC = 'imagem/carrinho.gif'/></A></TD>");
        out.println("</TR>");
        // Segundo produto
        out.println("<TR width = '%100'>");
        out.println("<TD width = '%20'> <IMG SRC = 'imagem/game2.jpg'/></TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Star Wars III</TD>");
        out.println("<TD width = '%10' class='gridCampo'>PS3</TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Jogo de aventura</TD>");
        out.println("<TD width = '%10' class='gridCampo'>R$ 80,00</TD>");
        out.println("<TD width = '%20' colspan = '2'><A HREF= 'adicionarProdutoCarrinho?idProduto=79' ><IMG SRC = 'imagem/carrinho.gif'/></A></TD>");
        out.println("</TR>");
        // Terceiro produto
        out.println("<TR width = '%100'>");
        out.println("<TD width = '%20'> <IMG SRC = 'imagem/game3.jpg'/></TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Dirt Shutdown</TD>");
        out.println("<TD width = '%10' class='gridCampo'>PS3</TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Jogo de Corrida</TD>");
        out.println("<TD width = '%10' class='gridCampo'>R$ 60</TD>");
        out.println("<TD width = '%20' colspan = '2'><A HREF= 'adicionarProdutoCarrinho?idProduto=83' ><IMG SRC = 'imagem/carrinho.gif'/></A></TD>");
        out.println("</TR>");
        // Quarto produto'
        out.println("<TR width = '%100'>");
        out.println("<TD width = '%20'> <IMG SRC = 'imagem/game4.jpg'/></TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Reckoning</TD>");
        out.println("<TD width = '%10' class='gridCampo'>PS3</TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Jogo de ação</TD>");
        out.println("<TD width = '%10' class='gridCampo'>R$ 99,00</TD>");
        out.println("<TD width = '%20' colspan = '2'><A HREF= 'adicionarProdutoCarrinho?idProduto=85' ><IMG SRC = 'imagem/carrinho.gif'/></A></TD>");
        out.println("</TR>");
        // Quinto produto
        out.println("<TR width = '%100'>");
        out.println("<TD width = '%20'> <IMG SRC = 'imagem/game5.jpg'/></TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Dance</TD>");
        out.println("<TD width = '%10' class='gridCampo'>PS3</TD>");
        out.println("<TD width = '%10'  class='gridCampo'>Jogo família</TD>");
        out.println("<TD width = '%10' class='gridCampo'>R$ 99,00</TD>");
        out.println("<TD width = '%20' colspan = '2'><A HREF= 'adicionarProdutoCarrinho?idProduto=86' ><IMG SRC = 'imagem/carrinho.gif'/></A></TD>");
        out.println("</TR>");
        // final da tabela de produtos
        out.println("</TABLE>");
        out.println("</body>");
        out.println("</html>");
    }
}
